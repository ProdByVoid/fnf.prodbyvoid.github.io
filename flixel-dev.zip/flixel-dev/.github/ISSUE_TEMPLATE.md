- **Haxe version:** ?.?.?
- **Flixel version:** ?.?.?
- **OpenFL version:** ?.?.?
- **Lime version:** ?.?.?
- **Affected targets:**

________________________________

**Code snippet reproducing the issue**:

```haxe
package;

import flixel.FlxState;

class PlayState extends FlxState
{
	override public function create():Void
	{
		// insert your code here
	}
}
```

________________________________

**Observed behavior:**

**Expected behavior:**
